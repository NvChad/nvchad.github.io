import{b as t,q as a,k as i,t as o}from"./web-DqPol8Cv.js";import{M as c}from"./index-yHsRVhWw.js";var s=o('<iframe width=560 height=315 src="https://www.youtube.com/embed/NHC4jLoR_zI?si=E9upX0ZWT-c5q7v6"title="YouTube video player"frameborder=0 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"referrerpolicy=strict-origin-when-cross-origin allowfullscreen>'),l=o('<iframe width=560 height=315 src="https://www.youtube.com/embed/VauET3tR2J4?si=cT1BTkgXweBTNZWW"title="YouTube video player"frameborder=0 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"referrerpolicy=strict-origin-when-cross-origin allowfullscreen>');const u={title:"Volt framework",desc:"Build Interactive UI for Neovim using the Volt framework! 100% Mouse friendly",cover:"volt.webp",order:4};function n(r){const e={a:"a",h1:"h1",h2:"h2",img:"img",p:"p",...c(),...r.components};return[t(e.h1,{children:"Volt UI Framework"}),`
`,t(e.p,{get children(){return t(e.img,{src:"/news/volt.webp",alt:"volt plugins"})}}),`
`,t(e.h2,{children:"Introduction"}),`
`,t(e.p,{children:"Volt is a Neovim plugin to create interactive UIs within Neovim!"}),`
`,t(e.h2,{children:"Volt Showcase"}),`
`,t(e.h2,{children:"Minty"}),`
`,t(e.p,{get children(){return["Beautiful color picker tool for Neovim. ",t(e.a,{href:"https://github.com/NvChad/minty",children:"repo url"})]}}),`
`,t(e.p,{get children(){return[t(e.img,{src:"https://github.com/user-attachments/assets/d499748b-d9c8-4a92-89ba-bfce1814c275",alt:"shades"}),`
`,t(e.img,{src:"https://github.com/user-attachments/assets/504ba2a1-9d83-492c-9913-f0e159ef9ad8",alt:"huefy"})]}}),`
`,i(s),`
`,t(e.h2,{children:"Menu"}),`
`,t(e.p,{get children(){return["Extensible menu & sub-menus creator . ",t(e.a,{href:"https://github.com/NvChad/menu",children:"repo url"})]}}),`
`,t(e.p,{get children(){return[t(e.img,{src:"https://github.com/user-attachments/assets/c8402279-b86d-432f-ad11-14a76c887ab1",alt:"image"}),`
`,t(e.img,{src:"https://github.com/user-attachments/assets/d70430e1-74d2-40dd-ba60-0b8919d53af6",alt:"image"})]}}),`
`,i(l)]}function d(r={}){const{wrapper:e}={...c(),...r.components};return e?t(e,a(r,{get children(){return t(n,r)}})):n(r)}export{d as default,u as meta};
