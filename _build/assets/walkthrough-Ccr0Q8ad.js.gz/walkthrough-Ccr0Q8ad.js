import{b as n,q as o,k as h,t as i}from"./web-DqPol8Cv.js";import{M as l}from"./index-yHsRVhWw.js";import{B as c}from"./basic-SBzF2FJM.js";var a=i("<kbd>space");const g={title:"NvChad Walkthrough",desc:"Walkthrough guide for NvChad"};function r(t){const e={a:"a",blockquote:"blockquote",code:"code",h2:"h2",li:"li",p:"p",ul:"ul",...l(),...t.components};return[n(e.h2,{children:"How does NvChad work?"}),`
`,n(e.blockquote,{get children(){return[`
`,n(e.p,{children:"NvChad's starter repo is the actual config and it uses the main NvChad repo as a plugin"}),`
`]}}),`
`,n(c,{}),`
`,n(e.h2,{children:"Chadrc.lua"}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{children:"This file is used to configure ui & base46 plugin"}),`
`,n(e.li,{get children(){return["Its meant to have structure of ",n(e.a,{href:"https://github.com/NvChad/ui/blob/v2.5/lua/nvconfig.lua",children:"nvconfig.lua"})]}}),`
`,n(e.li,{get children(){return["It should be in your config's ",n(e.code,{children:"/lua"})," folder"]}}),`
`]}}),`
`,n(e.h2,{children:"Themes"}),`
`,n(e.p,{get children(){return["You can see all the themes with the following keymap: ",n(e.code,{children:"<leader> + th"}),"."]}}),`
`,n(e.blockquote,{get children(){return[`
`,n(e.p,{get children(){return["The ",n(e.code,{children:"leader"})," key is the  ",h(a),"  in NvChad."]}}),`
`]}}),`
`,n(e.h2,{children:"Mappings"}),`
`,n(e.p,{children:"If you want to know all the keymaps, you can run the following commands:"}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{get children(){return n(e.code,{children:"NvCheatsheet"})}}),`
`,n(e.li,{get children(){return n(e.code,{children:"Telescope keymaps"})}}),`
`]}})]}function m(t={}){const{wrapper:e}={...l(),...t.components};return e?n(e,o(t,{get children(){return n(r,t)}})):r(t)}export{m as default,g as meta};
