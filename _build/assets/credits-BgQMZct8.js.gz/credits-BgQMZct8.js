import{M as i}from"./index-yHsRVhWw.js";import{b as n,q as h}from"./web-DqPol8Cv.js";function r(t){const e={a:"a",li:"li",p:"p",strong:"strong",ul:"ul",...i(),...t.components};return[n(e.p,{children:"The NvChad team would love to acknowledge many projects which made this possible."}),`
`,n(e.p,{children:"Thank you!"}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{get children(){return[`
`,n(e.p,{get children(){return[n(e.a,{href:"https://github.com/vim/vim",children:"Vim"})," & ",n(e.a,{href:"https://github.com/neovim/neovim",children:"NeoVim"})]}}),`
`]}}),`
`,n(e.li,{get children(){return[`
`,n(e.p,{children:"Plugin maintainers."}),`
`]}}),`
`,n(e.li,{get children(){return[`
`,n(e.p,{children:"Other NeoVim configurations which inspired @siduck to create NvChad:"}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/LunarVim/LunarVim",children:"LunarVim"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/SpaceVim/SpaceVim",children:"SpaceVim"})}}),`
`]}}),`
`]}}),`
`,n(e.li,{get children(){return[`
`,n(e.p,{get children(){return["Thanks to ",n(e.a,{href:"https://t.me/ufoludek",children:"ufoludek"}),' for making fun of me when I (@siduck) was using "codeblocks" ( 3 years ago ). I got to know from him that vim could do the same thing which got me interested in vim.']}}),`
`]}}),`
`]}}),`
`,n(e.p,{get children(){return n(e.strong,{children:"Some people who helped me a lot :"})}}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/elianiva",children:"elianava"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/ii14",children:"ii14"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/max397574",children:"max397574"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/lucario387",children:"lucario"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/tamton-aquib",children:"tamton-aquib"})}}),`
`,n(e.li,{get children(){return n(e.a,{href:"https://github.com/vhyrro",children:"vhyrro"})}}),`
`]}})]}function o(t={}){const{wrapper:e}={...i(),...t.components};return e?n(e,h(t,{get children(){return n(r,t)}})):r(t)}export{o as default};
